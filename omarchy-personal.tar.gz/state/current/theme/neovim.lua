return {
  {
    "omacom/aether.nvim",
    branch = "v3",
    name = "aether",
    priority = 1000,
    opts = {
      colors = {
        bg = "#15171C",
        dark_bg = "#101116",
        darker_bg = "#08090C",
        lighter_bg = "#252830",

        fg = "#F2F3F7",
        dark_fg = "#8B909B",
        light_fg = "#CFD2DA",
        bright_fg = "#FFFFFF",
        muted = "#707785",

        red = "#FF5F57",
        yellow = "#FEBC2E",
        orange = "#FF9F0A",
        green = "#28C840",
        cyan = "#64D2FF",
        blue = "#0A84FF",
        magenta = "#BF5AF2",
        brown = "#AC8E68",

        bright_red = "#FF6961",
        bright_yellow = "#FFD60A",
        bright_green = "#30D158",
        bright_cyan = "#70D7FF",
        bright_blue = "#409CFF",
        bright_magenta = "#DA8FFF",

        accent = "#7C91FF",
        cursor = "#FFFFFF",
        foreground = "#F2F3F7",
        background = "#15171C",
        selection = "#33416B",
        selection_foreground = "#FFFFFF",
        selection_background = "#33416B",
      },
    },
  },
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "aether",
    },
  },
}
