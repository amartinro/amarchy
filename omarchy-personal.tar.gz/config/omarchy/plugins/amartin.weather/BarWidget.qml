import QtQuick
import qs.Commons
import qs.Ui

BarWidget {
  id: root
  moduleName: "omarchy.weather"

  function injectPanel() {
    var target = panelLoader.item
    if (!target) return
    if ("bar" in target) target.bar = root.bar
    if ("settings" in target) target.settings = root.settings
    if ("anchorItem" in target) target.anchorItem = button
    if ("hostWidget" in target) target.hostWidget = root
  }

  function refresh() {
    if (panelLoader.item && panelLoader.item.refresh) panelLoader.item.refresh()
  }

  function togglePanel() {
    if (panelLoader.item && panelLoader.item.toggle) panelLoader.item.toggle()
  }

  // Shape contract for shell.summon/hide/toggle routing (Bar.findPanelWidget
  // requires open/close/opened on the bar-widget root). Open maps to the
  // panel's hotkey path so summoning suppresses the center hover reveal,
  // matching what the old per-plugin IpcHandler did.
  readonly property bool opened: panelLoader.item ? panelLoader.item.opened === true : false

  function open() {
    if (panelLoader.item && panelLoader.item.openFromHotkey) panelLoader.item.openFromHotkey()
  }

  function close() {
    if (panelLoader.item && panelLoader.item.close) panelLoader.item.close()
  }

  // Forwarded so this widget can stand in for the panel as the bar's popout
  // identity: Bar.requestPopout prefers closeForPopoutSwitch over close, and
  // KeyboardPanel reads popoutSwitchClosing back off its owner.
  readonly property bool popoutSwitchClosing: panelLoader.item ? panelLoader.item.popoutSwitchClosing === true : false

  function closeForPopoutSwitch() {
    if (panelLoader.item) panelLoader.item.closeForPopoutSwitch()
  }

  visible: panelLoader.item && panelLoader.item.barLabel !== ""
  implicitWidth: button.implicitWidth
  implicitHeight: button.implicitHeight

  onBarChanged: injectPanel()
  onSettingsChanged: injectPanel()

  Loader {
    id: panelLoader
    active: true
    source: Qt.resolvedUrl("Panel.qml")
    visible: false
    onLoaded: {
      root.injectPanel()
      Qt.callLater(root.injectPanel)
    }
  }

  // WidgetButton rather than the stock BarIconButton: the pill carries text,
  // and BarIconButton pins fixedWidth to slotSize, so anything longer than an
  // icon overflows the slot and overlaps the neighbouring widgets.
  //
  // The built-in label is hidden and the row below paints the reading itself:
  // the condition icon, then now / max / min. Only the min is dimmed, so the
  // day's floor reads as the quiet end of the range; the arrows keep max and
  // min distinguishable at a glance even in a monospace font where 28° and
  // 18° differ by one glyph. Width is set from the row because a hidden label
  // reports zero width, and the slot sizes off implicitWidth.
  WidgetButton {
    id: button
    anchors.fill: parent
    bar: root.bar
    labelVisible: false
    hasVisualContent: panelLoader.item ? panelLoader.item.barLabel !== "" : false
    fixedWidth: hiLoRow.implicitWidth + scaledHorizontalMargin * 2
    horizontalMargin: 8.75
    verticalPadding: 8.75
    // Tooltip suppressed because the panel is the detail view.
    tooltipText: ""

    onPressed: function(b) {
      if (!root.bar) return
      if (b === Qt.RightButton) root.bar.run("omarchy-notification-send \"$(omarchy-weather-status)\"")
      else if (b === Qt.MiddleButton) root.refresh()
      else root.togglePanel()
    }

    Row {
      id: hiLoRow
      anchors.centerIn: parent
      spacing: Style.space(6)

      Text {
        textFormat: Text.PlainText
        visible: text !== ""
        text: panelLoader.item ? panelLoader.item.label : ""
        color: button.foreground
        font.family: button.fontFamily
        font.pixelSize: Style.bar.iconFont
        anchors.verticalCenter: parent.verticalCenter
      }

      // Now: the plain number, so the unmarked value is the live one.
      Text {
        textFormat: Text.PlainText
        visible: text !== ""
        text: panelLoader.item ? panelLoader.item.barNowTemp : ""
        color: button.foreground
        font.family: button.fontFamily
        font.pixelSize: Style.font.body
        anchors.verticalCenter: parent.verticalCenter
      }

      // Arrow and number are separate items with a token gap between them:
      // one Text would have to join them with a space glyph, and in the bar's
      // monospace font a space costs a full digit's width — width the clock
      // beside the pill would rather have.
      //
      // The gap is md because the arrow's ink is wider than its advance
      // (10px of glyph in a 7.5px cell at body size): anything smaller
      // measured zero empty columns between the arrowhead and the digits in
      // a screenshot of the bar.
      Row {
        visible: maxTemp.text !== ""
        spacing: Style.spacing.md

        Text {
          textFormat: Text.PlainText
          text: "\uF062"
          color: button.foreground
          font.family: button.fontFamily
          font.pixelSize: Style.font.body
          anchors.verticalCenter: parent.verticalCenter
        }

        Text {
          id: maxTemp
          textFormat: Text.PlainText
          text: panelLoader.item ? panelLoader.item.barMaxTemp : ""
          color: button.foreground
          font.family: button.fontFamily
          font.pixelSize: Style.font.body
          anchors.verticalCenter: parent.verticalCenter
        }
      }

      Row {
        visible: minTemp.text !== ""
        spacing: Style.spacing.md

        Text {
          textFormat: Text.PlainText
          text: "\uF063"
          color: Qt.darker(button.foreground, 1.5)
          font.family: button.fontFamily
          font.pixelSize: Style.font.body
          anchors.verticalCenter: parent.verticalCenter
        }

        Text {
          id: minTemp
          textFormat: Text.PlainText
          text: panelLoader.item ? panelLoader.item.barMinTemp : ""
          color: Qt.darker(button.foreground, 1.5)
          font.family: button.fontFamily
          font.pixelSize: Style.font.body
          anchors.verticalCenter: parent.verticalCenter
        }
      }
    }
  }
}
