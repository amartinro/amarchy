-- Hyprland plugins.
--
-- Hyprbars (title bars, used by the Tahoe theme) and Hymission (Mission
-- Control) are built by hyprpm into its cache. Hyprland 0.56 no longer loads
-- hyprpm's enabled plugins on its own, so each one has to be named here.
-- Loading from the config also means a broken plugin shows up in
-- `hyprctl configerrors` instead of failing silently the way `hyprpm reload`
-- did from autostart.
--
-- Which plugins are wanted still comes from hyprpm's state, so `hyprpm
-- enable|disable` keeps working - the tahoe-dark theme-set hook uses it to turn
-- title bars off for other themes.
--
-- Plugin binaries are ABI-locked to the exact Hyprland build. After every
-- Hyprland update rebuild them, then restart Hyprland:
--
--   hyprpm update    # prompts for sudo
--
-- If that step is skipped the plugins refuse to load and the desktop loses its
-- title bars and Mission Control, but still starts.

local cache = "/var/cache/hyprpm/" .. (os.getenv("USER") or "amartin")

local function read(path)
  local file = io.open(path)
  if not file then
    return nil
  end
  local body = file:read("*a")
  file:close()
  return body
end

local function exists(path)
  local file = io.open(path, "rb")
  if not file then
    return false
  end
  file:close()
  return true
end

-- hyprpm stores one state.toml per repository: [plugin] enabled = true|false.
local function hyprpm_enabled(repo, plugin)
  local body = read(cache .. "/" .. repo .. "/state.toml")
  if not body then
    return false
  end

  local section, enabled
  for line in body:gmatch("[^\n]+") do
    local name = line:match("^%s*%[([^%]]+)%]%s*$")
    if name then
      section = name
    elseif section == plugin then
      local flag = line:match("^%s*enabled%s*=%s*(%a+)")
      if flag then
        enabled = flag == "true"
      end
    end
  end

  return enabled == true
end

local function load_plugin(name, repo, path)
  if not hyprpm_enabled(repo, name) then
    return
  end

  if not exists(path) then
    pcall(function()
      hl.notification.create({
        text = ("Plugin '%s' is enabled but not built.\nRun `hyprpm update`, then restart Hyprland."):format(name),
        timeout = 8000,
      })
    end)
    return
  end

  hl.plugin.load(path)
end

load_plugin("hyprbars", "hyprland-plugins", cache .. "/hyprland-plugins/hyprbars.so")
load_plugin("hymission", "hymission", cache .. "/hymission/hymission.so")
