# Hermarchy Quickshell Agent Surface

This optional user-local Omarchy plugin is the first visual consumer of
`agent-state.schema.json`. It keeps the persistent bar signal deliberately
small and opens a richer numbered panel on click.

```text
idle         HERMES ·          muted
executing    HERMES ●          cyan
waiting      HERMES ● INPUT    amber
completed    HERMES ● DONE     green (collector retains it for five minutes)
failed       HERMES ● FAILED   red (collector retains it for five minutes)
unavailable  HERMES ·          muted
unknown      HERMES ·          muted
```

The panel shows only contract-backed fields: agent name and state, task and detail,
model and provider, active workers, node, gateway, last activity, and end reason.
Optional values are omitted when absent; long activity text is bounded to two
lines and metadata is right-elided so the meaningful prefix survives on narrow
displays. It does not display token, context, memory, skill, tool, or utilization
guesses.

## Architecture

```text
Hermes structured local state
  -> hermarchy-agent-state adapter
  -> agent-state.schema.json validator
  -> hermarchy-state-read
  -> StateModel.js fail-muted projection
  -> native Omarchy bar widget and click panel
```

The Linux reader acts as a child subreaper, captures at most 64 KiB, gives
collection a five-second deadline and validation a one-second deadline, and
enforces both with a one-second hard-kill grace. It kills and reaps the complete
descendant tree—including children that create a new session—before validating
and emitting those exact bytes. If Linux process-tree inspection is unavailable,
the reader kills the known process group as a best effort and fails closed rather
than treating the tree as empty.
Invalid output, oversized output, a timeout, or a failed refresh becomes
`unknown`/muted. `StateModel.js` independently checks the complete record
shape, enums, timestamps, field types, and terminal-state invariants before
using it.
The plugin never writes runtime state and does not patch package-owned Omarchy,
Quickshell, or Hyprland files.

## Requirements

- Omarchy v4 with its user-local Quickshell plugin API;
- Linux, `python3`, `omarchy`, and `omarchy-shell`;
- Hermes only if live agent state is desired.

Hermes is not installed or configured here. When its executable is absent, the
validated result is `unavailable`/muted.

## Install

From the installed theme clone:

```sh
theme_dir="$(omarchy theme dir hermarchy)"
"$theme_dir/extras/quickshell/install.sh"
```

That explicit opt-in action:

1. rejects symlinked `$HOME` ancestors, destination components, and existing
   plugin-tree entries, and requires Omarchy validation;
2. builds the exact plugin payload in a private temporary staging directory and
   validates it before writing either destination;
3. anchors the real `$HOME` directory and creates every destination through
   no-follow directory descriptors, so a path replaced after prevalidation is
   never traversed;
4. transactionally swaps the adapter at `~/.local/bin/hermarchy-agent-state`
   and the plugin at
   `~/.config/omarchy/plugins/io.github.archer-clawbot.hermarchy-agent`;
5. holds the installed adapter and plugin descriptors, requires exact staged
   bytes and file names, validates a private snapshot of the installed plugin
   bytes, then reopens every destination ancestor from the anchored `$HOME` and
   compares ancestor and artifact identities plus final bytes; it also rechecks
   the absolute `$HOME` identity and restores both complete prior artifacts on
   any swap, read-back, identity, mutation, or validation failure;
6. explicitly rescans discovery and enables the plugin immediately before the
   native Agents widget unless `--no-enable` was requested.

To copy and validate without changing the active bar layout:

```sh
"$theme_dir/extras/quickshell/install.sh" --no-enable
```

Then enable it later:

```sh
omarchy plugin enable io.github.archer-clawbot.hermarchy-agent --before omarchy.agents
```

Middle-click the bar signal to refresh immediately. The normal polling interval
is two seconds and can be adjusted through Omarchy's bar widget settings.

## Update, reinstall, or recover

After `omarchy theme update`, rerun the installer from the refreshed theme
clone:

```sh
theme_dir="$(omarchy theme dir hermarchy)"
"$theme_dir/extras/quickshell/install.sh"
```

The same command supports an older complete payload, already-correct files, and
a partial user-local installation where only the adapter or plugin remains. If
copying completed while the shell was unavailable, rescan and enable after the
shell starts:

```sh
omarchy-shell shell rescanPlugins
omarchy plugin enable io.github.archer-clawbot.hermarchy-agent --before omarchy.agents
```

## Disable

```sh
omarchy plugin disable io.github.archer-clawbot.hermarchy-agent
```

Disabling removes the widget from the active bar but keeps its user-local files
for later re-enablement.

## Remove

```sh
omarchy plugin remove io.github.archer-clawbot.hermarchy-agent --yes
```

The adapter is shared with the command-line contract workflow and is therefore
not removed automatically. Remove it separately only when nothing else uses it:

```sh
rm "$HOME/.local/bin/hermarchy-agent-state"
```

## Tests

```sh
python3 -m unittest tests.test_agent_state tests.test_quickshell_plugin -v
QT_QPA_PLATFORM=offscreen /usr/lib/qt6/bin/qmltestrunner \
  -input tests/quickshell -import /usr/share/omarchy/shell
```
