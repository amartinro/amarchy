#!/usr/bin/env bash
# One-command installer: clones the theme into ~/.config/omarchy/themes and
# applies it. Omarchy drops *.lua (neovim.lua) and terminal configs from
# themes installed via `omarchy theme install` (anything carrying .git).
# Stripping .git marks the theme as user-written, so every file ships
# exactly as authored — Neovim gets noir.nvim with the pure_black variant.
set -euo pipefail

THEME=noir
REPO=https://github.com/tahadx/omarchy-noir-theme.git
DEST="$HOME/.config/omarchy/themes/$THEME"

rm -rf "$DEST"
git clone --depth 1 "$REPO" "$DEST"
rm -rf "$DEST/.git"

omarchy theme set "$THEME"
