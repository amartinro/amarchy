-- Extra autostart processes.
-- o.launch_on_start("my-service")

-- Hyprland plugins are loaded from hypr/plugins.lua now. Hyprland 0.56 stopped
-- auto-loading hyprpm's plugins, and `hyprpm reload` here raced the config, so
-- it failed silently whenever a plugin was stale.
