-- Learn how to configure Hyprland: https://wiki.hypr.land/Configuring/Start/

-- Omarchy's bootstrap keeps path setup out of this user config.
dofile((os.getenv("OMARCHY_PATH") or "/usr/share/omarchy") .. "/default/hypr/bootstrap.lua")

-- Load plugins before anything configures them (theme, Mission Control).
require("hypr.plugins")

-- Disable all Omarchy default bindings. Add your own in hypr/bindings.lua.
-- omarchy_default_bindings = false
--
-- Or disable only bindings for Omarchy's preinstalled apps/web apps while
-- keeping core window-manager bindings:
-- omarchy_preinstalled_bindings = false

-- Load Omarchy defaults.
require("default.hypr.omarchy")

-- Put your personal overrides in these files. They're loaded after Omarchy's
-- defaults so package updates can improve the defaults without rewriting your
-- ~/.config/hypr files.
require("hypr.monitors")
require("hypr.input")
require("hypr.bindings")
require("hypr.mouse")
require("hypr.looknfeel")
require("hypr.autostart")

-- Toggle config flags dynamically.
require("default.hypr.toggles")

-- Add any other personal Hyprland configuration below.
-- o.window("qemu", { workspace = "5" })

-- Default file manager: open floating, rectangular, centered on the monitor.
o.window(
  "(com.thisisgm.flea|org.gnome.Nautilus|Thunar|Dolphin|PCManFM|Nemo|Caja|XFE|Konqueror)",
  { float = true, center = true, size = { "(monitor_w*0.6)", "(monitor_h*0.6)" } }
)

-- Mouse Mapper (MX Master 3 button mapping): floating, centered settings window.
o.window({ title = "Mouse Mapper" }, { float = true, center = true, size = { 620, 680 } })

-- Bitwarden: open a bit larger than the default 875x600 floating size.
o.window("^(Bitwarden)$", { size = { 1000, 750 } })

-- Tahoe Dark post-user look overrides (installed by omactheme).
require("hypr.tahoe-overrides")

-- Tahoe Mission Control (installed by omactheme).
require("hypr.mission-control")
